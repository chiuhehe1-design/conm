# 🏷️ Whop / Gumroad Listing: Agency Automation Kit (n8n + AI Copilot)

**Target Pricing:** $99.00 (Single Agency License) | $199.00 (Developer / Resell License)
**Format:** Instant Download (Docker Compose + 15 Production n8n Workflows + Video Walkthrough Guide)
**Target Audience:** Digital Marketing Agencies, Automation Consultants, Freelancers, B2B Founders

---

## 📢 Listing Copy (Copy-Paste Ready)

### 📌 Title:
`Agency In A Box: 15 Production-Ready n8n & WhatsApp AI Automation Workflows (Self-Hosted, $0 Zapier Bill)`

### 💡 Short Tagline:
`Ditch $300+/month Zapier bills. Deploy an enterprise-grade self-hosted n8n automation engine in 3 minutes with pre-wired AI lead qualification, WhatsApp notifications, and automated invoicing.`

### 🎯 Body Description:
Are you tired of paying astronomical bills to Zapier or Make.com every time your webhooks fire?
Do your agency clients demand instant AI-driven follow-ups and automated reporting?

The **Agency Automation Kit** is an end-to-end, battle-tested automation infrastructure built on open-source **n8n**.
You can host it on any $5/month VPS (or your own server) and run **unlimited tasks with zero per-execution fees**.

### 🔥 What Workflows Are Included:
1. **Instant Lead Capture & AI Qualification:** Intercepts Facebook Lead Ads / Typeform / Webhook -> Runs Claude/GPT analysis -> Qualifies budget -> Routes to CRM.
2. **24/7 WhatsApp & Telegram AI Assistant:** Auto-replies to prospect inquiries with context-aware responses and books calendar calls.
3. **Automated Weekly Client ROI PDF Generator:** Aggregates metrics from Google Sheets/Stripe and emails polished branded executive summaries.
4. **Stripe & Paddle Payment Webhook Sync:** Automatically provisions access, sends invoice PDFs, and pings your private Slack/Discord team channel.
5. **Cold Outreach Warmup & Bounce Cleaner:** Automates email list sanitation and verifies DNS MX records before sending.
6. **Social Media Multi-Platform Auto-Distributor:** Turns 1 markdown post into Twitter threads, LinkedIn carousels, and Telegram announcements.

### 📦 Deliverables Inside:
- `docker-compose.yml`: 1-Click production launch with PostgreSQL and SSL auto-renewal.
- 15x Ready-to-import `.json` workflow blueprints.
- Step-by-step setup documentation (No coding required, just fill in your API keys).
- Full source code with commercial usage rights (Sell this as a $1,500 setup service to your clients!).

---

### 💳 Pricing:
- **Standard Agency ($99.00):** Full access to all 15 workflows + Docker stack + lifetime updates.
- **Agency Reseller ($199.00):** Unlimited client deployment rights + White-label client documentation template.
