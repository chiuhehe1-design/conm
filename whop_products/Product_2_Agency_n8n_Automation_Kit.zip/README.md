# Build Automation with n8n Flows and RAG Chatbot
- **Lead ID:** 403
- **Budget:** £375 - £750 GBP
- **Platform:** freelancer
- **Direct Job Link:** https://www.freelancer.com/projects/dot-net/Build-Automation-with-Flows-RAG.html
- **Auto-Generated:** 2026-10-12 22:29:26

## Scope & Technical Requirements
I’m looking for a professional who can assist in building two key AI projects for my portfolio: 1. Automating P1 & P2 issue ticketing using n8n flows: This involves creating workflows that automatically generate tickets based on the severity of issues, ensuring seamless automation…

## System Architecture Checklist
- [x] Repository Scaffolding & Directory Layout
- [x] Invariant & Sanity Test Suite
- [x] Docker Container Configuration
- [ ] Core Business Logic Implementation
- [ ] Production Verification & Client Handover
