import pytest
from src.main import execute

def test_system_sanity():
    assert execute() is True
