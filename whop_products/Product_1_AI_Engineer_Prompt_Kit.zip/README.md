# 🚀 The Antigravity AI Engineer Master Prompt Kit (v2026.1)
### 350+ Battle-Tested Production Prompts for Autonomous AI Coding, Reverse Engineering, Web3 Security, and High-Yield Automation

Designed specifically for **Claude 3.5 Sonnet / Opus 5.5, OpenAI GPT-4o, Cursor IDE, Windsurf, and Antigravity Agent Swarms**.

---

## 📦 What's Inside This Pack

1. **Category 1: Autonomous Coding & TDD Architecture (75 Prompts)**
   - Strict Test-Driven Development (Red-Green-Refactor)
   - Zero-Regression Bug Squashing
   - Zero-Mocking Real Integration Verification
   - Large-Scale Codebase Refactoring & De-bloating
   - Concurrency, Race Condition, & Deadlock Detection

2. **Category 2: Stealth Web Scraping & Anti-Bot Evasion (60 Prompts)**
   - Cloudflare Turnstile, DataDome & PerimeterX Evasion Architecture
   - Headless Playwright & Puppeteer Fingerprint Masking
   - Rotating Proxy Pool & Residential Gateway Orchestration
   - Reverse Engineering Private Mobile & WebSocket APIs

3. **Category 3: Web3 Smart Contracts & Security Audits (65 Prompts)**
   - EVM Reentrancy, Flash Loan & Price Oracle Manipulation Audits
   - Foundry & Hardhat Fuzzing Invariant Test Generation
   - Solana Anchor & Rust Memory Safety Vulnerability Scanners
   - Gas Optimization & Assembly (Yul) Micro-Tweaks

4. **Category 4: High-Yield Freelance & Bounty Winning (70 Prompts)**
   - Top-1% Upwork & Freelancer Proposal Generator (Tailored to Job Pain Points)
   - GitHub Issue & Bounty Solution Proposal Generator (Expensify / Algora / Polar style)
   - Client Objection Handling & Scope Creep Defense Scripts
   - Retainer Upsell & Value-Based Pricing Calculators

5. **Category 5: Production DevOps & Cloud Infrastructure (80 Prompts)**
   - Docker Compose Multi-Stage Production Builds
   - Nixpacks & Caddy Reverse Proxy Config Generators
   - Systemd Self-Healing Daemon Watchdogs & Healthcheck Alerters
   - SQLite to Postgres Zero-Downtime Data Migration Scripts

---

## 🛠️ How To Use

- **For Cursor / Windsurf / Antigravity:** Copy the system prompt block into `.cursorrules` or system prompt input.
- **For Claude Web / ChatGPT:** Paste the Master System Meta-Prompt as Project Instructions.
- **For Automated Bots:** Import `prompts_catalog.json` into your agentic execution pipeline.

---
*Created by Antigravity Engineering Lab. Licensed for personal & commercial use.*
