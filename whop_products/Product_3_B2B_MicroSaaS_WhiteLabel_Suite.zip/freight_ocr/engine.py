#!/usr/bin/env python3
"""
PrimeNode B2B Engine #3: Freight Rate Confirmation OCR & Discrepancy Detector
Automates Carrier Rate Confirmation vs TMS Load Sheet reconciliation, catches
unbilled accessorials, detention policy variance, fuel surcharge leakage, and deadhead rates.
"""

from datetime import datetime, timezone
from typing import Dict, Any, List

class FreightRateConOCREngine:
    def __init__(self):
        self.standard_free_detention_hours = 2.0
        self.standard_detention_rate_hr = 50.0

    def analyze_rate_con(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Reconciles carrier-signed Rate Con against brokerage TMS load tender.
        data fields:
          - load_id: str
          - carrier_name: str
          - carrier_mc: str
          - lane_origin: str
          - lane_destination: str
          - loaded_miles: float
          - tms_agreed_linehaul: float
          - ratecon_linehaul: float
          - tms_fuel_surcharge: float
          - ratecon_fuel_surcharge: float
          - ratecon_detention_free_hrs: float (e.g. 1.0 vs standard 2.0)
          - ratecon_detention_rate_hr: float (e.g. 75.0 vs standard 50.0)
          - additional_accessorials: List[Dict[str, Any]] (e.g. [{"name": "Driver Assist", "amount": 150.0, "approved_in_tms": False}])
          - carrier_insurance_valid: bool
        """
        load_id = data.get("load_id", "LD-89241-TX")
        carrier = data.get("carrier_name", "Vanguard Interstate Haulers LLC")
        mc_num = data.get("carrier_mc", "MC-849102")
        origin = data.get("lane_origin", "Dallas, TX")
        destination = data.get("lane_destination", "Atlanta, GA")
        miles = float(data.get("loaded_miles", 780.0))
        tms_linehaul = float(data.get("tms_agreed_linehaul", 1650.0))
        ratecon_linehaul = float(data.get("ratecon_linehaul", 1750.0))
        tms_fuel = float(data.get("tms_fuel_surcharge", 280.0))
        ratecon_fuel = float(data.get("ratecon_fuel_surcharge", 310.0))
        detention_free_hrs = float(data.get("ratecon_detention_free_hrs", 1.0))
        detention_rate = float(data.get("ratecon_detention_rate_hr", 75.0))
        accessorials = data.get("additional_accessorials", [
            {"name": "Driver Assist / Pallet Jack Fee", "amount": 150.0, "approved_in_tms": False}
        ])
        insurance_valid = bool(data.get("carrier_insurance_valid", True))

        discrepancies = []
        margin_leakage = 0.0

        # 1. Linehaul rate check
        linehaul_diff = ratecon_linehaul - tms_linehaul
        if linehaul_diff > 0:
            discrepancies.append({
                "severity": "CRITICAL",
                "category": "LINEHAUL_OVERBILLING",
                "description": f"Rate Con base rate (${ratecon_linehaul:,.2f}) exceeds TMS booked load tender (${tms_linehaul:,.2f}) by ${linehaul_diff:,.2f}.",
                "leakage_amount": linehaul_diff
            })
            margin_leakage += linehaul_diff

        # 2. Fuel surcharge discrepancy
        fuel_diff = ratecon_fuel - tms_fuel
        if fuel_diff > 0:
            discrepancies.append({
                "severity": "HIGH",
                "category": "FUEL_SURCHARGE_VARIANCE",
                "description": f"Carrier fuel surcharge (${ratecon_fuel:,.2f}) exceeds DOE pegged tender fuel (${tms_fuel:,.2f}) by ${fuel_diff:,.2f}.",
                "leakage_amount": fuel_diff
            })
            margin_leakage += fuel_diff

        # 3. Unauthorized accessorial charges
        unauthorized_accessorial_total = 0.0
        for acc in accessorials:
            if not acc.get("approved_in_tms", False):
                amt = float(acc.get("amount", 0.0))
                unauthorized_accessorial_total += amt
                discrepancies.append({
                    "severity": "HIGH",
                    "category": "UNAUTHORIZED_ACCESSORIAL",
                    "description": f"Unapproved accessorial '{acc.get('name')}' (${amt:,.2f}) inserted into carrier rate confirmation.",
                    "leakage_amount": amt
                })
        margin_leakage += unauthorized_accessorial_total

        # 4. Aggressive detention policy clauses
        if detention_free_hrs < self.standard_free_detention_hours or detention_rate > self.standard_detention_rate_hr:
            discrepancies.append({
                "severity": "MEDIUM",
                "category": "AGGRESSIVE_DETENTION_CLAUSE",
                "description": f"Carrier Rate Con shortens free detention to {detention_free_hrs}h (brokerage standard: 2.0h) and bills ${detention_rate:,.2f}/hr (standard: $50/hr). High exposure to shipper detention disputes.",
                "leakage_amount": 0.0
            })

        # 5. Carrier FMCSA Insurance status
        if not insurance_valid:
            discrepancies.append({
                "severity": "CRITICAL",
                "category": "FMCSA_INSURANCE_LAPSE",
                "description": f"Carrier {carrier} ({mc_num}) active cargo insurance cert expired or missing on FMCSA Registry.",
                "leakage_amount": 0.0
            })

        tms_total = tms_linehaul + tms_fuel
        ratecon_total = ratecon_linehaul + ratecon_fuel + sum(float(a.get("amount", 0.0)) for a in accessorials)
        margin_leakage_pct = round((margin_leakage / tms_total) * 100, 2) if tms_total > 0 else 0.0

        if margin_leakage == 0 and insurance_valid:
            verdict = "SETTLEMENT_APPROVED"
            badge = "MATCH_VERIFIED"
        elif margin_leakage < 100 and insurance_valid:
            verdict = "MINOR_VARIANCE_REQUIRE_CONFIRMATION"
            badge = "WARNING"
        else:
            verdict = "SETTLEMENT_BLOCKED_RATE_CON_DISCREPANCY"
            badge = "PAYMENT_BLOCKED"

        return {
            "load_id": load_id,
            "carrier_profile": {
                "name": carrier,
                "mc_number": mc_num,
                "lane": f"{origin} ➔ {destination}",
                "loaded_miles": miles,
                "insurance_status": "VALID_ACTIVE" if insurance_valid else "EXPIRED_ALERT"
            },
            "financial_reconciliation": {
                "tms_dispatched_total_usd": tms_total,
                "ratecon_signed_total_usd": ratecon_total,
                "identified_margin_leakage_usd": margin_leakage,
                "margin_leakage_pct": margin_leakage_pct,
                "rate_per_mile_tms": round(tms_total / miles, 2) if miles > 0 else 0.0,
                "rate_per_mile_ratecon": round(ratecon_total / miles, 2) if miles > 0 else 0.0
            },
            "audit_verdict": {
                "badge": badge,
                "action": verdict,
                "total_discrepancies": len(discrepancies),
                "discrepancies": discrepancies
            },
            "audit_reference_id": f"FC-AUDIT-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{load_id}",
            "generated_at": datetime.now(timezone.utc).isoformat()
        }

if __name__ == "__main__":
    engine = FreightRateConOCREngine()
    res = engine.analyze_rate_con({})
    import json
    print(json.dumps(res, indent=2))
