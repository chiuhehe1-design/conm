#!/usr/bin/env python3
"""
PrimeNode B2B Engine #2: Subcontractor Lien Waiver Extraction & Compliance Engine
Automates statutory California (Civil Code § 8132-8138) and Texas (Property Code § 53.281)
progress & final waiver validation, retention math auditing, and AIA G702/G703 reconciliation.
"""

import re
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional

class LienWaiverComplianceEngine:
    def __init__(self):
        self.supported_jurisdictions = ["California (Civil Code § 8132-8138)", "Texas (Property Code § 53.281)", "Standard ConsensusDocs"]

    def analyze_waiver(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyzes a pay-application waiver submission against contract parameters.
        data fields:
          - subcontractor_name: str
          - trade: str (e.g. 'Drywall & Framing', 'Electrical', 'HVAC')
          - contract_value: float
          - prior_billed: float
          - current_draw: float
          - retention_rate: float (e.g. 0.05 or 0.10)
          - waiver_type: str ('conditional_progress', 'unconditional_progress', 'conditional_final', 'unconditional_final')
          - state: str ('CA', 'TX', 'OTHER')
          - through_date: str (YYYY-MM-DD)
          - pay_app_cutoff_date: str (YYYY-MM-DD)
          - notary_present: bool
          - claimed_exceptions: float (unbilled/disputed claims stated on waiver)
        """
        sub_name = data.get("subcontractor_name", "Pacific Framing Inc.")
        trade = data.get("trade", "Structural Framing")
        contract_val = float(data.get("contract_value", 450000.0))
        prior_billed = float(data.get("prior_billed", 180000.0))
        current_draw = float(data.get("current_draw", 45000.0))
        retention_rate = float(data.get("retention_rate", 0.05))
        waiver_type = data.get("waiver_type", "conditional_progress")
        state = data.get("state", "CA").upper()
        through_date = data.get("through_date", "2026-09-30")
        pay_app_cutoff = data.get("pay_app_cutoff_date", "2026-09-30")
        notary_present = bool(data.get("notary_present", True))
        claimed_exceptions = float(data.get("claimed_exceptions", 0.0))

        flags = []
        is_compliant = True
        risk_score = 0.0

        # 1. Mathematical reconciliation
        total_billed = prior_billed + current_draw
        billed_percentage = round((total_billed / contract_val) * 100, 2) if contract_val > 0 else 0.0
        retention_withheld = round(current_draw * retention_rate, 2)
        net_payable_after_retention = round(current_draw - retention_withheld, 2)

        if total_billed > contract_val:
            flags.append({
                "severity": "CRITICAL",
                "code": "OVERBILLING_EXCEEDS_SUBCONTRACT",
                "message": f"Cumulative billing (${total_billed:,.2f}) exceeds total contract value (${contract_val:,.2f}) by ${total_billed - contract_val:,.2f}. Unapproved Change Order required."
            })
            is_compliant = False
            risk_score += 40.0

        # 2. Date alignment
        if through_date != pay_app_cutoff:
            flags.append({
                "severity": "HIGH",
                "code": "THROUGH_DATE_MISMATCH",
                "message": f"Waiver through-date ({through_date}) does not align with pay application billing cut-off date ({pay_app_cutoff}). GC exposed to gap claims."
            })
            is_compliant = False
            risk_score += 25.0

        # 3. Notary requirements for unconditional waivers (Texas statutory requirement)
        if "unconditional" in waiver_type:
            if state == "TX" and not notary_present:
                flags.append({
                    "severity": "CRITICAL",
                    "code": "STATUTORY_NOTARY_MISSING_TX",
                    "message": "Texas Property Code § 53.281 strictly voids unconditional waivers lacking a valid statutory notary acknowledgment seal."
                })
                is_compliant = False
                risk_score += 35.0
            elif not notary_present:
                flags.append({
                    "severity": "MEDIUM",
                    "code": "NOTARY_SEAL_ABSENT",
                    "message": "Unconditional waiver submitted without notary verification. GC risk policy advises notary for draws >$25k."
                })
                risk_score += 15.0

        # 4. Claimed exceptions / reservation of rights
        if claimed_exceptions > 0:
            flags.append({
                "severity": "HIGH",
                "code": "EXCEPTION_RESERVATION_STATED",
                "message": f"Subcontractor explicitly reserved ${claimed_exceptions:,.2f} in disputed extra claims on waiver face. Draw release must exclude disputed balance."
            })
            risk_score += 20.0

        # Overall recommendation
        if risk_score == 0:
            recommendation = "CLEARED_FOR_DISBURSEMENT"
            badge = "APPROVED"
        elif risk_score < 30:
            recommendation = "APPROVE_WITH_STANDARD_CONDITIONS"
            badge = "CONDITIONAL_APPROVAL"
        else:
            recommendation = "HOLD_PAYMENT_PENDING_REMEDY"
            badge = "PAYMENT_HOLD"

        return {
            "subcontractor": sub_name,
            "trade": trade,
            "state_jurisdiction": state,
            "waiver_type": waiver_type.replace("_", " ").title(),
            "contract_reconciliation": {
                "original_contract": contract_val,
                "prior_billed": prior_billed,
                "current_draw": current_draw,
                "total_billed_to_date": total_billed,
                "billed_percent": billed_percentage,
                "retention_rate_pct": retention_rate * 100,
                "retention_withheld_usd": retention_withheld,
                "net_payable_usd": net_payable_after_retention
            },
            "compliance_status": {
                "badge": badge,
                "is_compliant": is_compliant,
                "risk_score_100": min(100.0, risk_score),
                "recommendation": recommendation,
                "flags_count": len(flags),
                "flags": flags
            },
            "statutory_reference": "California Civil Code § 8132" if state == "CA" else ("Texas Property Code § 53.281" if state == "TX" else "General Commercial UCC § 2-206"),
            "audit_certificate_id": f"LW-CERT-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{abs(hash(sub_name)) % 10000:04d}",
            "generated_at": datetime.now(timezone.utc).isoformat()
        }

if __name__ == "__main__":
    engine = LienWaiverComplianceEngine()
    test_sample = {
        "subcontractor_name": "Apex Framing & Drywall LLC",
        "trade": "Framing",
        "contract_value": 320000.0,
        "prior_billed": 140000.0,
        "current_draw": 38000.0,
        "retention_rate": 0.05,
        "waiver_type": "conditional_progress",
        "state": "CA",
        "through_date": "2026-09-30",
        "pay_app_cutoff_date": "2026-09-30",
        "notary_present": True,
        "claimed_exceptions": 0.0
    }
    res = engine.analyze_waiver(test_sample)
    import json
    print(json.dumps(res, indent=2))
