# Checkout Links — Go-Live Checklist (OWNER ACTION REQUIRED)

All Paddle checkout URLs in the repo are currently **placeholders** of the form
`https://buy.paddle.com/checkout?product=<slug>`. They render fine in the UI but
cannot accept money until replaced with real checkout links from your Paddle
dashboard (requires Paddle account + KYC — human-blocked, ~15 min).

## Owner steps (one-time)

1. Create/verify Paddle account → complete seller KYC.
2. Create one Paddle Product + Price per slug below (prices are the agreed tiering).
3. Copy each real checkout URL (Checkout Links or `buy.paddle.com/product/<id>`).
4. Search-and-replace each placeholder URL repo-wide (the validator lists every location).
5. Run the go-live gate — it must print **PASS** before any outreach email fires:
   ```bash
   python3 scripts/validate_checkout_links.py        # exit 1 while placeholders remain
   python3 scripts/validate_checkout_links.py --list # full inventory with file:line
   ```

## Placeholder slug inventory (17 slugs / 43 uses)

| Slug | Price | Product | Key locations |
|---|---|---|---|
| `agency_copilot_199` | $199/mo | Client Reporting Copilot — Pilot | `b2b_products/hub/hub.html`, mailer, outreach dossiers |
| `agency_copilot_audit_49` | $49 one-time | Copilot — Single-Account Audit | mailer, dossiers |
| `agency_copilot_annual_1990` | $1,990/yr | Copilot — Annual | retention/upsell dossier |
| `agency_copilot_scale_499` | $499/mo | Copilot — Scale | retention/upsell dossier |
| `lien_waiver_audit_49` | $49 one-time | LienShield — Draw Audit | `lien_waiver/landing_page.html`, mailer |
| `lien_waiver_pro_299` | $299/mo | LienShield — Pro Autopilot | landing page, hub, mailer |
| `lien_waiver_enterprise_799` | $799/mo | LienShield — Enterprise | landing page |
| `freight_ocr_audit_49` | $49 one-time | Freight OCR — Margin Audit | `freight_ocr/landing_page.html`, mailer |
| `freight_ocr_pro_349` | $349/mo | Freight OCR — Broker Autopilot | landing page, hub, mailer |
| `freight_ocr_scale_699` | $699/mo | Freight OCR — Fleet Scale | landing page |
| `bates_privilege_audit_49` | $49 one-time | Bates Stamping — Matter Audit | `bates_stamping/landing_page.html`, mailer |
| `bates_privilege_pro_199` | $199/mo | Bates Stamping — Paralegal Co-pilot | landing page, hub, mailer |
| `bates_privilege_firm_499` | $499/mo | Bates Stamping — Firm Plan | landing page |
| `tech_sourcing_pilot_79` | $79 | Tech Sourcing — Pilot | recruiting playbook |
| `tech_sourcing_retainer_499` | $499/mo | Tech Sourcing — Retainer | recruiting playbook |

(Plus 2 markdown-artifact variants with a trailing backtick in
`objection_defense_pricing_wedge_dossier.md` — replace alongside their base slugs.)

## Note on sending email

`RESEND_API_KEY` is already configured and verified working (sandbox sender
`onboarding@resend.dev` delivers to the owner inbox). To email prospects
**directly**, verify a sending domain at https://resend.com/domains and set
`RESEND_FROM_EMAIL` accordingly — otherwise every dispatch is staged to your
own inbox with a 1-click `mailto:` fallback.
