# Base EVM DEX Arbitrage Suite

## Overview
Automated triangular & cross-DEX arbitrage scanner connecting directly to Base Mainnet (Chain ID 8453).

## Requirements
- Python 3.9+
- Internet connection & Base RPC endpoint (default: public `https://mainnet.base.org`)

## Quickstart
```bash
python3 arbitrage_engine.py
```
