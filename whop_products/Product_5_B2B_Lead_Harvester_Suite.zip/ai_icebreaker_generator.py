#!/usr/bin/env python3
"""
AI Cold Outreach Icebreaker & Email Personalization Engine
Turns raw lead lists into high-converting 3-sentence personalized cold emails.
"""

def generate_cold_email(lead: dict) -> str:
    biz = lead.get("business_name", "your business")
    name = lead.get("decision_maker", "there").split()[0]
    niche = lead.get("niche", "industry")
    city = lead.get("city", "your area")

    email_body = f"""Subject: Quick question regarding {biz}'s client acquisition

Hi {name},

Noticed {biz}'s strong reputation in {city} across the {niche} space. 

We recently built an automated system that helped similar firms generate 15-20 qualified appointments/month on autopilot without paying for ad spend.

Are you open to a 3-minute video showing exactly how it works for {biz}?

Best regards,
Lam Vu
"""
    return email_body

if __name__ == "__main__":
    sample_lead = {
        "business_name": "Austin Premier Dental",
        "decision_maker": "Dr. Sarah",
        "city": "Austin, TX",
        "niche": "Dentistry"
    }
    print("📧 Generated Personalized Cold Email:")
    print(generate_cold_email(sample_lead))
