#!/bin/bash
# 🛰️ DePIN Passive Income Fleet Deployer
# 1-Click setup for multi-node bandwidth sharing on Ubuntu 22.04 / 24.04 LTS

set -e

echo "=========================================================="
echo "🚀 Initializing DePIN Multi-Node Orchestrator"
echo "=========================================================="

# Check root
if [ "$EUID" -ne 0 ]; then
  echo "❌ Please run as root (sudo ./depin_fleet_deployer.sh)"
  exit 1
fi

# Install Docker if missing
if ! command -v docker &> /dev/null; then
    echo "📦 Installing Docker engine..."
    apt-get update -qq && apt-get install -y -qq docker.io docker-compose-plugin
fi

echo "✅ Docker ready. Configuring DePIN container stack..."

cat << 'DOCKER_EOF' > docker-compose.depin.yml
version: '3.8'

services:
  packetstream:
    image: packetstream/psclient:latest
    container_name: depin_packetstream
    restart: always
    environment:
      - CID=${PACKETSTREAM_CID:-default_cid}

  watchdog:
    image: python:3.11-slim
    container_name: depin_watchdog
    restart: always
    volumes:
      - ./node_watchdog.py:/app/node_watchdog.py
    working_dir: /app
    command: python3 -u node_watchdog.py
DOCKER_EOF

echo "✨ Configuration complete! Run 'docker compose -f docker-compose.depin.yml up -d' to start earning."
