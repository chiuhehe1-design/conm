#!/usr/bin/env python3
"""
DePIN 24/7 Node Watchdog & Telegram Uptime Reporter
"""

import time
import subprocess
import urllib.request
import json

TELEGRAM_BOT_TOKEN = "YOUR_BOT_TOKEN"
TELEGRAM_CHAT_ID = "YOUR_CHAT_ID"

def check_nodes():
    res = subprocess.run(["docker", "ps", "--format", "{{.Names}}"], capture_output=True, text=True)
    running = res.stdout.strip().split("\n")
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Active DePIN Nodes: {len(running)}")
    return running

if __name__ == "__main__":
    print("🛰️ DePIN Fleet Watchdog Started...")
    while True:
        check_nodes()
        time.sleep(300) # Check every 5 minutes
