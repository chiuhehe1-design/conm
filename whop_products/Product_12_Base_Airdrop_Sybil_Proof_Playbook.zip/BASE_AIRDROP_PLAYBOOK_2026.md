# 🛡️ Base EVM Airdrop & Sybil-Proof Farming Playbook (2026 Edition)

A step-by-step master guide to qualifying for tier-1 onchain airdrops on Base, Ethereum L2s, and Farcaster without triggering anti-Sybil cluster filters.

---

### Phase 1: Identity & Anti-Sybil Fortification
1. **Never Fund from the Same CEX Sub-Account:** Withdrawing from Binance or OKX directly to multiple addresses creates clear onchain cluster links. Always randomize amounts and use sub-accounts or diverse bridges.
2. **Timing Poisson Randomization:** Never execute transactions at fixed cron intervals (e.g. exactly every 24 hours). Use random intervals between 14 hours and 78 hours.
3. **Organic Contract Interaction Diversity:**
   - Don't just swap tokens.
   - Vote on Snapshot DAOs.
   - Deploy a simple ERC-721 contract via Thirdweb or Remix.
   - Mint a free Zora / Base commemorative NFT.
   - Deposit liquidity into Uniswap v3 or Aerodrome pool.

---

### Phase 2: Top Tier-1 Base Ecosystem Protocols
1. **Aerodrome Finance:** Supply liquidity to volatile pairs (WETH/AERO or USDC/AERO) for native AERO emissions and veAERO voting power.
2. **Farcaster / Warpcast:** Maintain active FID, hold 1+ Power Badge criteria, interact with frames, and link your Base EVM wallet.
3. **Bountycaster & TaskMarket:** Complete at least 1 verified micro-task onchain to establish proof-of-work reputation.
4. **Virtuals Protocol & DeAI Agents:** Stake in agent tokens (LUNA, AIXBT) or run inference testnet nodes.
